package com.example.influx_test_2;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class SoilMoisture extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soil_moisture);
        TextView tv = findViewById(R.id.tan);
        GraphView graphView = findViewById(R.id.idGraphView);
        Button button = findViewById(R.id.Button3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            //InfluxDB influxDB = InfluxDBFactory.connect("http://172.16.34.34:8086", "admin", "admin");
                            InfluxDB influxDB = InfluxDBFactory.connect("http://192.168.10.62:8086 ", "admin", "admin" );
                            influxDB.setLogLevel(InfluxDB.LogLevel.NONE);
                            influxDB.setDatabase("mp");
                            if (influxDB != null) {
                                String sql1 = "SELECT soilMoisture FROM \"dhtsm1\" order by time desc limit 1 ";
                                String sql = "SELECT soilMoisture FROM \"dhtsm1\" ";
                                System.out.println("hello1");
                                QueryResult queryResult = influxDB.query(new Query(sql), TimeUnit.MILLISECONDS);
                                QueryResult queryResult1 = influxDB.query(new Query(sql1), TimeUnit.MILLISECONDS);

                                List<QueryResult.Result> res1 = queryResult1.getResults();
                                List<QueryResult.Result> res = queryResult.getResults();

                                //System.out.println(res.get(0).getSeries());
                                //System.out.println(res.get(0).getSeries().get(0).getColumns());

                                //System.out.println(queryResult);
                                //System.out.println(res);
                                Double soilMoistureLevel = (Double) res1.get(0).getSeries().get(0).getValues().get(0).get(1);
                                tv.setText(soilMoistureLevel.toString());
                                List sm = (List) res.get(0).getSeries().get(0).getValues();
                                //Object sm2 =  res.get(0).getSeries().get(0).getValues().get(0).get(1);
                                //System.out.println(sm.subList(1, 4));
                                System.out.println(sm);
                                List ml1 = new ArrayList();
                                //System.out.println(sm2);
                                System.out.println("hi");

                                for(int i = 0; i < sm.size(); i++)
                                {
                                    ml1.add(res.get(0).getSeries().get(0).getValues().get(i).get(0));
                                    //Object sm2 =  res.get(0).getSeries().get(0).getValues().get(0).get(1);
                                    //System.out.println(sm2);
                                }
                                //System.out.println(sm2);
                                List ml2 = new ArrayList();
                                //System.out.println(ml1);
                                for(int i = 0; i < sm.size(); i++)
                                {
                                    ml2.add(res.get(0).getSeries().get(0).getValues().get(i).get(1));
                                }
                                System.out.println(ml2);
                                //System.out.println(res.get(0).getSeries().get(0).getValues().get(0).get(1));
                                System.out.println("Hello 2");

                                //System.out.println(sm1);

                                //QueryResult.Series series1 = new QueryResult.Series();
                                //System.out.println("series=" );
                                //System.out.println(series1 );
                                //System.out.println(series1.getColumns() );
                                //System.out.println(series1.getValues() );

                                //String[] result = getResources().getStringArray(R.array.res);
                                //ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,res);
                                //tv2.setAdapter(adapter);
                                //System.out.println(res.get(0).getSeries().get(0).getValues().get(0));
                                //System.out.println("hello3");
                                //System.out.println(res.get(0).getSeries().get(0));
                                //System.out.println(res.get(0).getSeries().get(1));
                                //System.out.println(res.get(0).getSeries());

                                //Result [series=[Series [name=random_numbers, tags=null, columns=[time, value], values=[[1.650133058582E12, 75.0]]]], error=null]

                                    //sm = ml1.get(i);
                                    LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
                                    //series.setColor(Color.WHITE);
                                        for(int i = 0; i < sm.size(); i++) {

                                            DataPoint point = new DataPoint((Double) ml1.get(i), (Double) ml2.get(i));
                                            series.appendData(point, true, sm.size());
                                        }
                                    graphView.addSeries(series);

                                //graphView.getGridLabelRenderer().setGridColor(Color.RED);
                                        //System.out.println(series.getHighestValueY());
                                        //System.out.println(series.getLowestValueY());
                                    graphView.setTitle("Graph of Soil Moisture ");
                                    graphView.setTitleColor(R.color.white);
                                    graphView.setTitleTextSize(20);


                            } else {
                                Log.d(TAG, "not fetched ");
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                });
                thread.start();
            }
        });


    }
}