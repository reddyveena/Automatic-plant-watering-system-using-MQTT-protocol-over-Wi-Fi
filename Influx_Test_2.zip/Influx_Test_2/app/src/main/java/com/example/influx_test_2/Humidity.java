package com.example.influx_test_2;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class Humidity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_humidity);

        TextView tvtemp = findViewById(R.id.ttemp);
        TextView tvhumid = findViewById(R.id.thumid);
        Button button = findViewById(R.id.button3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            //InfluxDB influxDB = InfluxDBFactory.connect("http://172.16.34.34:8086", "admin", "admin");
                            InfluxDB influxDB = InfluxDBFactory.connect("http://192.168.113.62:8086", "admin", "admin");
                            influxDB.setLogLevel(InfluxDB.LogLevel.NONE);
                            influxDB.setDatabase("mp");
                            if (influxDB != null) {
                                String sql = "SELECT temperature,humidity FROM \"dhtsm\" order by time desc limit 1 ";
                                System.out.println("hello1");
                                QueryResult queryResult = influxDB.query(new Query(sql), TimeUnit.MILLISECONDS);

                                List<QueryResult.Result> res = queryResult.getResults();

                                //System.out.println(queryResult);
                                System.out.println(res);
                                String temp = (String) res.get(0).getSeries().get(0).getValues().get(0).get(1);
                                String humid = (String) res.get(0).getSeries().get(0).getValues().get(0).get(2);

                                //QueryResult.Series series = new QueryResult.Series();
                                //System.out.println("series=" );
                                //System.out.println(series );
                                //System.out.println(series.getColumns() );
                                //System.out.println(series.getValues() );

                                tvtemp.setText(temp);
                                tvhumid.setText(humid);

                                //String[] result = getResources().getStringArray(R.array.res);
                                //ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1,res);
                                //tv2.setAdapter(adapter);
                                //System.out.println(res.get(0).getSeries().get(0).getValues().get(0));
                                System.out.println("hello3");
                                //System.out.println(res.get(0).getSeries().get(0));
                                //System.out.println(res.get(0).getSeries().get(1));
                                //System.out.println(res.get(0).getSeries());

                                //Result [series=[Series [name=random_numbers, tags=null, columns=[time, value], values=[[1.650133058582E12, 75.0]]]], error=null]
                            } else {
                                Log.d(TAG, "not fetched ");
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                });
                thread.start();
            }
        });
    }
}