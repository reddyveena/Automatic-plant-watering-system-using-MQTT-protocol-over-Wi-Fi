package com.example.influx_test_2;

import static android.content.ContentValues.TAG;

import static com.example.influx_test_2.R.color.white;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class TempHumid extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_temp_humid);

        TextView tvtemp = findViewById(R.id.ttemp);
        TextView tvhumid = findViewById(R.id.thumid);
        Button button = findViewById(R.id.button3);
        GraphView graphView2 = findViewById(R.id.idGraphView2);
        GraphView graphView3 = findViewById(R.id.idGraphView3);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            //InfluxDB influxDB = InfluxDBFactory.connect("http://172.16.34.34:8086", "admin", "admin");
                            InfluxDB influxDB = InfluxDBFactory.connect("http://192.168.10.62:8086", "admin", "admin");
                            influxDB.setLogLevel(InfluxDB.LogLevel.NONE);
                            influxDB.setDatabase("mp");
                            if (influxDB != null) {
                                String sql2 = "precision rfc3339";
                                influxDB.query(new Query(sql2));
                                String sql1 = "SELECT temperature,humidity FROM \"dhtsm1\" order by time desc limit 1 ";
                                String sql = "SELECT temperature,humidity FROM \"dhtsm1\" ";
                                System.out.println("hello1");
                                QueryResult queryResult = influxDB.query(new Query(sql), TimeUnit.MILLISECONDS);
                                QueryResult queryResult1 = influxDB.query(new Query(sql1), TimeUnit.MILLISECONDS);
                                List<QueryResult.Result> res = queryResult.getResults();
                                List<QueryResult.Result> res1 = queryResult1.getResults();
                                System.out.println(res1);
                                System.out.println("queryResult");
                                Double temp = (Double) res1.get(0).getSeries().get(0).getValues().get(0).get(1);
                                Double humid = (Double) res1.get(0).getSeries().get(0).getValues().get(0).get(2);

                                tvtemp.setText(temp.toString());
                                tvhumid.setText(humid.toString());

                                List th = (List) res.get(0).getSeries().get(0).getValues();

                                List ml = new ArrayList();
                                List ml1 = new ArrayList();
                                //System.out.println(sm2);
                                System.out.println("hi");

                                for(int i = 0; i < th.size(); i++)
                                {
                                    ml.add(res.get(0).getSeries().get(0).getValues().get(i).get(0));

                                }
                                System.out.println(ml);
                                List ml2 = new ArrayList();

                                for(int i = 0; i < th.size(); i++)
                                {
                                    ml1.add(res.get(0).getSeries().get(0).getValues().get(i).get(1));
                                }
                                System.out.println(ml1);

                                for(int i = 0; i < th.size(); i++)
                                {
                                    ml2.add(res.get(0).getSeries().get(0).getValues().get(i).get(2));
                                }
                                System.out.println(ml2);

                                LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
                                //series.setColor(Color.WHITE);
                                for(int i = 0; i < th.size(); i++) {

                                    DataPoint point = new DataPoint((Double) ml.get(i), (Double) ml1.get(i));
                                    series.appendData(point, true, th.size());
                                }
                                graphView2.addSeries(series);
                                graphView2.setTitle("Graph of Temperature ");
                                graphView2.setTitleColor(white);
                                graphView2.setTitleTextSize(20);

                                LineGraphSeries<DataPoint> series2 = new LineGraphSeries<>();
                                //series2.setColor(Color.WHITE);
                                for(int i = 0; i < th.size(); i++) {

                                    DataPoint point = new DataPoint((Double) ml.get(i), (Double) ml2.get(i));
                                    series2.appendData(point, true, th.size());
                                }
                                graphView3.addSeries(series2);
                                series2.setBackgroundColor(white);
                                graphView3.setTitle("Graph of Humidity ");
                                graphView3.setTitleColor(white);
                                graphView3.setTitleTextSize(20);

                            } else {
                                Log.d(TAG, "not fetched ");
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                });
                thread.start();
            }
        });
    }
}