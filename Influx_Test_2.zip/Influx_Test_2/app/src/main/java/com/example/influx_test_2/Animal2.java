package com.example.influx_test_2;

import static android.content.ContentValues.TAG;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Animal2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animal2);

        TextView time = findViewById(R.id.time);
        TextView tv = findViewById(R.id.tan2);
        Button button = findViewById(R.id.Button6);
        //GraphView graphView = findViewById(R.id.idGraphView4);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Thread thread = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {

                            //InfluxDB influxDB = InfluxDBFactory.connect("http://172.16.34.34:8086", "admin", "admin");
                            InfluxDB influxDB = InfluxDBFactory.connect("http://192.168.162.99:8086", "admin", "admin");
                            influxDB.setLogLevel(InfluxDB.LogLevel.NONE);
                            influxDB.setDatabase("mp");
                            if (influxDB != null) {
                                String sql1 = "SELECT * FROM \"animal2\" order by time desc limit 1 ";
                                String sql = "SELECT * FROM \"animal2\" ";
                                System.out.println("hello1");
                                QueryResult queryResult = influxDB.query(new Query(sql), TimeUnit.MILLISECONDS);
                                QueryResult queryResult1 = influxDB.query(new Query(sql1), TimeUnit.MILLISECONDS);

                                List<QueryResult.Result> res = queryResult.getResults();
                                List<QueryResult.Result> res1 = queryResult1.getResults();

                                System.out.println("hello2");
                                System.out.println(res1);
                                String time2 = String.valueOf(res1.get(0).getSeries().get(0).getValues().get(0).get(0));
                                String animal = String.valueOf(res1.get(0).getSeries().get(0).getValues().get(0).get(1));

                                System.out.println(animal);
                                tv.setText(animal);
                                time.setText(time2);

                                /*List sm = (List) res.get(0).getSeries().get(0).getValues();
                                List ml1 = new ArrayList();
                                //System.out.println(sm2);
                                System.out.println("hi");

                                for(int i = 0; i < sm.size(); i++)
                                {
                                    ml1.add(res.get(0).getSeries().get(0).getValues().get(i).get(0));
                                }
                                //System.out.println(sm2);
                                List ml2 = new ArrayList();
                                //System.out.println(ml1);
                                for(int i = 0; i < sm.size(); i++)
                                {
                                    ml2.add(res.get(0).getSeries().get(0).getValues().get(i).get(1));

                                }
                                System.out.println(ml2);
                                LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
                                //series.setColor(Color.WHITE);
                                for(int i = 0; i < sm.size(); i++) {

                                    DataPoint point = new DataPoint((Double) ml1.get(i), Double.parseDouble((String) ml2.get(i)));
                                    series.appendData(point, true, sm.size());
                                }
                                graphView.addSeries(series);

                                //graphView.getGridLabelRenderer().setGridColor(Color.RED);
                                //System.out.println(series.getHighestValueY());
                                //System.out.println(series.getLowestValueY());
                                graphView.setTitle("Graph of Soil Moisture ");
                                graphView.setTitleColor(R.color.white);
                                graphView.setTitleTextSize(20); */

                            } else {
                                Log.d(TAG, "not fetched ");
                            }


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }

                });
                thread.start();
            }
        });
    }
}